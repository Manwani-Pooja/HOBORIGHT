[![Habo logo](https://habo.space/img/feature.png "Logo Title Text 1")](https://habo.space)

![Codemagic build status](https://api.codemagic.io/apps/6154a5e032cdf915d1ce822b/6154a5e032cdf915d1ce822a/status_badge.svg)

[Habo](https://habo.space) is a simple open-source habit tracking application. It is created in the [Flutter](https://flutter.dev/) framework with a single codebase for Android and iOS. 

Currently available on the Play store.

[![Google play store](https://habo.space/img/en_get.svg)](https://play.google.com/store/apps/details?id=com.pavlenko.Habo)

[![Screens](https://habo.space/img/mockup.png)](https://habo.space)

Contributing Bug reports
------

If you are interested in contributing to this project. See the [contributing page](https://github.com/xpavle00/Habo/blob/master/CONTRIBUTING.md).

Support
------

If you like this project you can [buy me a coffee](https://www.buymeacoffee.com/peterpavlenko)

<a href="https://www.buymeacoffee.com/peterpavlenko" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>
