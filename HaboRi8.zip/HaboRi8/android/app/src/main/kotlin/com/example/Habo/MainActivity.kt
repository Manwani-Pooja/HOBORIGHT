package com.example.Habo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}